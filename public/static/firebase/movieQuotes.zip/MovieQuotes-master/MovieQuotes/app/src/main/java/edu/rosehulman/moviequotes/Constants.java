package edu.rosehulman.moviequotes;

/**
 * Created by Matt Boutell on 7/12/2016.
 * Rose-Hulman Institute of Technology.
 * Covered by MIT license.
 */
public class Constants {
    public static final String TAG = "MQ";
}
